#include "Graph.h"


Graph::Graph(std::string fileName){
    this->fileName = fileName;
    populateGraphVector();

}

void Graph::populateGraphVector(){
    charMap.resize(512);
    std::ifstream inFile;
    std::string line;
    inFile.open(this->fileName);
    int i = 0;
    while (getline(inFile, line)) {
        //
    // store each line in the vector
    if (line.size() == 512){
        
        for (auto &myChar : line){
            charMap[i].push_back(myChar);
        }
        i++;

    }
    
    }
    inFile.close();
}
void Graph::printCharMap(){
    for (auto &line :charMap){
        for (auto &myChar : line){
            std::cout << myChar;
        }
        std::cout << std::endl;
    }
    std::cout << std::endl;
    std::cout << charMap[3][0] << std::endl;
    std::cout << charMap[4][0] << std::endl;
}

void Graph::generateBoostGraph(){

    for (int i = 0; i <  512; i++){
        for(int j = 0; j < 512; j++){
            boost::add_vertex(adjList);
            
            //[i] row
            //[j] col
            
        } 
    } //CREATING VERTICES
   
   // adjList[261121].name='s';
   // std::cout<<adjList[261121].name;
    ///
    
    for (int i = 0; i <  512; i++){
        for(int j = 0; j < 512; j++){
            //[i] row
            //[j] col
               //test left
               
               if (j > 0){
                   if (charMap[i][j-1] == '.' ){
                   boost::add_edge((i*512)+j,(i*512)+j-1,1,adjList);
                   }
               }
               //test right
               if (j < 511){
                   if (charMap[i][j+1] == '.' ){
                   boost::add_edge((i*512)+j,(i*512)+j+1,1,adjList);
                   }
               }
               //test up
               if (i > 0){
                   if (charMap[i-1][j] == '.' ){
                   boost::add_edge((i*512)+j,((i-1)*(512)+j),1,adjList);
                   }
               }

               //test down
               if (i < 511){
                   if (charMap[i+1][j] == '.' ){
                   boost::add_edge((i*512+j),((i+1)*(512)+j),1,adjList);
                   }
               }
               //test leftup
               if (j > 0 && i > 0){
                   if (charMap[i-1][j-1] == '.' ){
                   boost::add_edge((i*512)+j,(i-1)*(512)+j-1,1,adjList);
                   }
               }
               //test leftdown
               if (j > 0 && i < 511){
                   if (charMap[i+1][j-1] == '.' ){
                   boost::add_edge((i*512)+j,(i+1)*(512)+j-1,1,adjList);
                   }
               }
               //test rightup
               if (j < 511 && i > 0){
                   if (charMap[i-1][j+1] == '.' ){
                   boost::add_edge((i*512)+j,(i-1)*(512)+j+1,1,adjList);
                   }
               }
               //test rightdown
               if (j < 511 && i < 511){
                   if (charMap[i+1][j+1] == '.' ){
                   boost::add_edge((i*512)+j,((i+1)*(512)+j+1),1,adjList);
                   }
               } 
               
        } 
    } //ADDING NEIGHBORS
   
}




std::vector<long unsigned int> Graph::testDijkstras(int startX, int startY, int endX, int endY){

    
    /*
    mygraph_t adjList;
    
    vertex_t A = boost::add_vertex(adjList);
    vertex_t B = boost::add_vertex(adjList);
    vertex_t C = boost::add_vertex(adjList);
    vertex_t D = boost::add_vertex(adjList);
    vertex_t E = boost::add_vertex(adjList);
    vertex_t F = boost::add_vertex(adjList);
    vertex_t G = boost::add_vertex(adjList);

    boost::add_edge(A,B,6,adjList);
    boost::add_edge(B,C,10,adjList);
    boost::add_edge(A,D,5,adjList);
    boost::add_edge(C,F,2,adjList);
    boost::add_edge(C,E,1,adjList);
    boost::add_edge(A,G,6,adjList);

    char names[] = "ABCDEFG";
    */
    
    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    vertex_t startNode = (startY*512) + startX;
    vertex_t endNode = (endY*512)+ endX;
    //start and end nodes@@@@@@@@@@@@@@@@@@@@@@@@@@@
    
    
    std::vector<vertex_t> p(boost::num_vertices(adjList));
    std::vector<int> d(boost::num_vertices(adjList));
    std::vector<Vertex> predecessors(boost::num_vertices(adjList));
    IndexMap indexmap = boost::get(boost::vertex_index, adjList);
    WeightMap weightmap = boost::get(boost::edge_weight_t(), adjList);
    boost::dijkstra_shortest_paths(adjList, startNode, &p[0], &d[0], weightmap, indexmap,std::less<int>(), boost::closed_plus<int>(), (std::numeric_limits<int>::max)(), 0,
                              boost::default_dijkstra_visitor());
     
    
    vertex_iter vCurr, vEnd;
    
      for (boost::tie(vCurr, vEnd) = vertices(adjList); vCurr!=vEnd; vCurr++) {
        std::cout << "Distance from " << startNode<< " to " << *vCurr << " is "  << d[*vCurr] << std::endl;
      
      }
      std::cout << std::endl;
      

      std::vector< vertex_t > path;
      path.reserve(500);
      vertex_t current = endNode;
        
        
      while(current!=startNode) {
          
          path.push_back(current);
          current=p[current];
          
      }
      

      path.push_back(startNode);
      return path;

      std::vector<vertex_t>::reverse_iterator currV;
      std::cout<< "Path taken from "<< "X:"<< startNode/512 <<" Y:"<<startNode%512 << " to " << "X:"<<endNode/512<< " Y:" << endNode%512<< " : " << std::endl ;
      for (currV=path.rbegin(); currV != path.rend(); currV++) {

          std::cout << "X:"<<*currV / 512 <<" Long:" << *currV%512<< " -> " << std::endl;
      }
      
      
}