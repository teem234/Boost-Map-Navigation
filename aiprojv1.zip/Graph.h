#include <iostream>
#include <deque>
#include <iterator>
#include <vector>
#include <fstream>
#include <string>

#include "boost/graph/adjacency_list.hpp"
#include "boost/graph/topological_sort.hpp"
#include "boost/graph/astar_search.hpp"
#include "boost/graph/dijkstra_shortest_paths.hpp"
#include "boost/functional/hash.hpp"

struct Vertex{
    char name;
    int visited;

    int x;
    int y;
};

struct EdgeProperties {
  double weight;

};
struct location
{
  float y, x; 
};

class endNode_visitor : public boost::default_bfs_visitor {
public:
    template <typename vertex_t, typename mygraph_t>
    void find_vertex(vertex_t end, mygraph_t &adjList)
    {
        std::cout<<"Found vertex " << end << std::endl;

    }
};
//custom visitor. unused. Used boost default visitor Below.
//can add properties to break when end node visited so we do not waste time searching when found already

typedef float cost;
typedef boost::adjacency_list<boost::listS, boost::vecS,boost::undirectedS,boost::no_property,EdgeProperties> gGraph;
typedef boost::adjacency_list<boost::listS, boost::vecS, boost::undirectedS,  Vertex,boost::property<boost::edge_weight_t, cost> > mygraph_t;
//typedef boost::adjacency_list<boost::listS, boost::vecS, boost::undirectedS, boost::no_property,boost::property<boost::edge_weight_t, cost> Graph2;
typedef typename boost::graph_traits<mygraph_t>::vertex_descriptor vertex_t;
//typedef typename boost::graph_traits<mygraph_t>::vertex_t_t_descriptor vertex_t;
typedef std::pair<int, int> edge;
typedef boost::property_map < mygraph_t, boost::vertex_index_t >::type IndexMap;

typedef boost::property_map<mygraph_t, boost::edge_weight_t>::type WeightMap;
typedef boost::graph_traits<mygraph_t>::vertex_iterator vertex_iter;


class Graph{

public:
    WeightMap weightmap;
    Graph(std::string fileName);
    std::vector<long unsigned int> testDijkstras(int startX, int startY, int endX, int endY);
    void printCharMap();
    void generateBoostGraph();

private:
    void populateGraphVector();
    std::string fileName;
    mygraph_t adjList;
    std::vector<std::vector<char> > charMap;

    std::vector<std::vector<vertex_t> > vertexMap;

};