
#include <iostream>
#include <CImg.h>
#include "Graph.h"

using namespace cimg_library;

int main(){
    Graph test("moonglade.map");
    
    test.generateBoostGraph();
    std::vector<long unsigned int> path = test.testDijkstras(125,451,159,448);
    //test.printCharMap();
    
    
    const unsigned char color[] = {255, 0, 0};
    CImg<unsigned char> image("moonglade.jpg"), visu(500,400,3,0);

    //image.draw_line(0, 0, 125, 125, color);
    CImgDisplay mainDisplay(image, "MoonGlade");
    
    int offsetX = 63;
    int offsetY = 133;

    while(!mainDisplay.is_closed()){
        //std::cout<<image.atXY(61,84)<<std::endl;
        for (int i = 0; i < path.size(); i++){

            int x = path[i]%512 + offsetX;
            int y = path[i]/512 + offsetY;
          
            //for(int j = 0; j < image.height(); j++){
            image.draw_point(x, y, color);
            image.display(mainDisplay);
            //mainDisplay.wait();
            //}////
        }
    }
    



}