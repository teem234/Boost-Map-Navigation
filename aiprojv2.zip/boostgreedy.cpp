//
// Created by td on 3/20/18.
//

//by Timothy Joyce
/*
#include <iostream>
#include <deque>
#include <iterator>
#include <vector>
#include <algorithm>

#include "boost/graph/adjacency_list.hpp"
#include "boost/graph/topological_sort.hpp"
#include "boost/graph/astar_search.hpp"
#include "boost/graph/dijkstra_shortest_paths.hpp"
#include "boost/functional/hash.hpp"

struct EdgeProperties {
    double weight;

};
struct Vertex{
    bool visited = false;
};

typedef float cost;
typedef boost::adjacency_list<boost::listS, boost::vecS,boost::undirectedS,boost::no_property,EdgeProperties> Graph;
typedef boost::adjacency_list<boost::listS, boost::vecS, boost::undirectedS,  Vertex,boost::property<boost::edge_weight_t, cost> > mygraph_t;
typedef typename boost::graph_traits<mygraph_t>::vertex_descriptor vertex_t;
typedef std::pair<int, int> edge;
typedef boost::property_map < mygraph_t, boost::vertex_index_t >::type IndexMap;
typedef boost::property_map<mygraph_t, boost::edge_weight_t>::type WeightMap;

int main()
{
    mygraph_t adjList;

    vertex_t A = boost::add_vertex(adjList);
    vertex_t B = boost::add_vertex(adjList);
    vertex_t C = boost::add_vertex(adjList);
    vertex_t D = boost::add_vertex(adjList);
    vertex_t E = boost::add_vertex(adjList);
    vertex_t F = boost::add_vertex(adjList);
    vertex_t G = boost::add_vertex(adjList);

    char names[] = "ABCDEFG";

    boost::add_edge(A,B,6,adjList);
    boost::add_edge(B,C,10,adjList);
    boost::add_edge(A,D,5,adjList);
    boost::add_edge(C,F,2,adjList);
    boost::add_edge(D,C,4,adjList);
    boost::add_edge(C,E,1,adjList);
    boost::add_edge(A,G,6,adjList);
    boost::add_edge(B,E,3,adjList);

    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    vertex_t startNode =B;
    vertex_t endNode = F;
    //nodes to search@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

    WeightMap weights = boost::get(boost::edge_weight_t(), adjList);
    boost::graph_traits <mygraph_t>::out_edge_iterator ei, ei_end;
    float weight=1000;
    vertex_t nextvertex;

    bool found = false;
    std::vector<vertex_t> path;
    adjList[startNode].visited = true;

    //Greedy search loop
    while (!found){


        weight = 1000;
        vertex_t source;
        vertex_t target;
        bool somefree = false;
        //bool used to check whether we ran into a dead end

        path.push_back(startNode);

         //FOR EACH EDGE OF STARTING VERTEX
        for (boost::tie(ei, ei_end) = boost::out_edges(startNode, adjList); ei != ei_end; ++ei) {

            source = boost::source ( *ei, adjList );
            target = boost::target ( *ei, adjList );
            std::cout << "There is an edge from " << names[source] <<  " to " << names[target] << std::endl;
            std::cout << "With edge weight : " << boost::get(weights, *ei) <<std::endl;

            if (target == endNode){
                std::cout<< "Found path to node!" << std::endl;
                path.push_back(endNode);
                found = true;
                break;
            }

            if (!adjList[target].visited){
                somefree = true;

                if (boost::get(weights,*ei) < weight){

                    nextvertex = target;
                    weight = boost::get(weights,*ei);
                }
            }
        }
        if (!somefree && !found) {
            std::cout<< "Dead end no path to node!" << std::endl;
            found=true;
            break;
        }

        startNode = nextvertex;
        adjList[target].visited = true;
    }

    std::cout<< "Path taken was " ;
    for(auto vert : path){
        std::cout << names[vert]<<"->";
    }
}

*/

