//
// Created by td on 3/20/18.
//

#include <iostream>
#include <deque>
#include <iterator>
#include <vector>

#include "boost/graph/adjacency_list.hpp"
#include "boost/graph/topological_sort.hpp"
#include "boost/graph/astar_search.hpp"
#include "boost/graph/dijkstra_shortest_paths.hpp"
#include "boost/functional/hash.hpp"

struct Vertex{
    char name;
    int visited;
};

struct EdgeProperties {
    double weight;

};

class endNode_visitor : public boost::default_bfs_visitor {
public:
    template <typename vertex_t, typename mygraph_t>
    void find_vertex(vertex_t end, mygraph_t &adjList)
    {
        std::cout<<"Found vertex " << end << std::endl;

    }
};
//custom visitor. unused. Used boost default visitor Below.
//can add properties to break when end node visited so we do not waste time searching when found already

typedef float cost;
typedef boost::adjacency_list<boost::listS, boost::vecS,boost::undirectedS,boost::no_property,EdgeProperties> Graph;
typedef boost::adjacency_list<boost::listS, boost::vecS, boost::undirectedS,  Vertex,boost::property<boost::edge_weight_t, cost> > mygraph_t;
//typedef boost::adjacency_list<boost::listS, boost::vecS, boost::undirectedS, boost::no_property,boost::property<boost::edge_weight_t, cost> Graph2;
typedef typename boost::graph_traits<mygraph_t>::vertex_descriptor vertex_t;
//typedef typename boost::graph_traits<mygraph_t>::vertex_t_t_descriptor vertex_t;
typedef std::pair<int, int> edge;
typedef boost::property_map < mygraph_t, boost::vertex_index_t >::type IndexMap;
typedef boost::property_map<mygraph_t, boost::edge_weight_t>::type WeightMap;
typedef boost::graph_traits<mygraph_t>::vertex_iterator vertex_iter;

template <class Graph, class CostType>
class distance_heuristic : public boost::astar_heuristic<mygraph_t, cost> {
public:
    typedef typename boost::graph_traits<mygraph_t>::vertex_descriptor Vertex;

    distance_heuristic(Vertex goal) : m_goal(goal) {}

    CostType operator()(Vertex u) {
        CostType dx = m_location[m_goal].x - m_location[u].x;
        CostType dy = m_location[m_goal].y - m_location[u].y;
        return ::sqrt(dx * dx + dy * dy);
    }

private:
    LocMap m_location;
    Vertex m_goal;
}


int main()
{
    mygraph_t adjList;

    vertex_t A = boost::add_vertex(adjList);
    vertex_t B = boost::add_vertex(adjList);
    vertex_t C = boost::add_vertex(adjList);
    vertex_t D = boost::add_vertex(adjList);
    vertex_t E = boost::add_vertex(adjList);
    vertex_t F = boost::add_vertex(adjList);
    vertex_t G = boost::add_vertex(adjList);

    boost::add_edge(A,B,6,adjList);
    boost::add_edge(B,C,10,adjList);
    boost::add_edge(A,D,5,adjList);
    boost::add_edge(C,F,2,adjList);
    boost::add_edge(C,E,1,adjList);
    boost::add_edge(A,G,6,adjList);

    char names[] = "ABCDEFG";

    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    vertex_t startNode = D;
    vertex_t endNode = F;
    //start and end nodes@@@@@@@@@@@@@@@@@@@@@@@@@@@

    std::vector<vertex_t> p(boost::num_vertices(adjList));
    std::vector<int> d(boost::num_vertices(adjList));
    std::vector<Vertex> predecessors(boost::num_vertices(adjList));
    IndexMap indexmap = boost::get(boost::vertex_index, adjList);
    WeightMap weightmap = boost::get(boost::edge_weight_t(), adjList);
    boost::dijkstra_shortest_paths(adjList, startNode, &p[0], &d[0], weightmap, indexmap,std::less<int>(), boost::closed_plus<int>(), (std::numeric_limits<int>::max)(), 0,
                                   boost::default_dijkstra_visitor());

    vertex_iter vCurr, vEnd;
    for (boost::tie(vCurr, vEnd) = vertices(adjList); vCurr != vEnd; vCurr++) {
        std::cout << "Distance from " << names[startNode]<< " to " << names[*vCurr] << " is "  << d[*vCurr] << std::endl;
    }
    std::cout << std::endl;

    std::vector< vertex_t > path;
    vertex_t current = endNode;

    while(current != startNode) {
        path.push_back(current);
        current=p[current];
    }
    path.push_back(startNode);

    std::vector<vertex_t>::reverse_iterator currV;
    std::cout<< "Path taken from "<< names[startNode] << " to " << names[endNode] << ": " << std::endl ;
    for (currV=path.rbegin(); currV != path.rend(); currV++) {

        std::cout << names[*currV] << " -> ";
    }




}
