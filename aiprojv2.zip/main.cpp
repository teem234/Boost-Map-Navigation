
#include <iostream>
#include <CImg.h>
#include "Graph.h"

using namespace cimg_library;

void drawGraph(std::vector<long unsigned int> path, const unsigned char color[],CImg<unsigned char> &image,CImgDisplay &mainDisplay);

int main(){
    
    Graph test("moonglade2.map");
    
    test.generateBoostGraph();
    
    /*THERE ARE SLIGHT INCONSISTENCIES IN THE OUTPUT DRAWING AS THE MAPFILE IS NOT COMPLETELY ACCURATE
    **TO THE IMAGE FILE-- EVEN WHEN IMAGE IS SCALED OR CROPPED TO ACCOUNT FOR IT 
    */
    
    
    
    const unsigned char dijkcolor[] = {0, 0, 255};
    const unsigned char astarcolor[] = {255, 0, 0};
    CImg<unsigned char> image("moongladeScale9.jpg"), visu(512,512,3,1);

    //image.draw_line(0, 0, 125, 125, color);
    CImgDisplay mainDisplay(image, "MoonGlade");

    //astar red, dijkstras blue
    drawGraph(test.AStar(107,130,332,74), astarcolor,image,mainDisplay);
    drawGraph(test.Dijkstras(107,130,332,74), dijkcolor,image,mainDisplay);
    
  

   while(!mainDisplay.is_closed());
    



}

void drawGraph(std::vector<long unsigned int> path, const unsigned char color[] , CImg<unsigned char> &image,CImgDisplay &mainDisplay){
     //while(!mainDisplay.is_closed()){
        //std::cout<<image.atXY(61,84)<<std::endl;
        for (int i = 0; i < path.size(); i++){

            int x = path[i]%512;
            int y = path[i]/512;
          
            //for(int j = 0; j < image.height(); j++){
            image.draw_point(x, y, color);
            image.display(mainDisplay);
            //mainDisplay.wait();
            //}////
        }
    //}
}